package config

import (
	"fmt"

	"github.com/BurntSushi/toml"
)

var config upfConfig

func init() {
	if _, err := toml.DecodeFile("../upf/config/config.toml", &config); err != nil {
		fmt.Println(err)
		return
	}
}

type upfConfig struct {
	Title        string
	Upftasks     map[string]upftasks
	Upffilepath  map[string]upffilepath
	Mysql        mysql
	Aerospike    aerospike
	Tagview      tagview
	Inttfilepath map[string]inttfilepath
	Dtfilepath   map[string]dtfilepath
}

type upftasks struct {
	Spec string
}

type upffilepath struct {
	Imei string
	Idfa string
}

type inttfilepath struct {
	Imei string
	Idfa string
}

type dtfilepath struct {
	Filepath string
}

type mysql struct {
	DataSourceName string
	MaxOpenConn    int
	MaxIdleConn    int
}

type aerospike struct {
	Asserver  string
	Port      int
	Namespase string
}

type tagview struct {
	UserProfileCr   string
	UserProfileIntt string
}

func GetUserProfileCr() string {
	return config.Tagview.UserProfileCr
}

func GetUserProfileIntt() string {
	return config.Tagview.UserProfileIntt
}

func GetUpfTasksMap() map[string]string {
	m := make(map[string]string)
	for taskName, upfTasks := range config.Upftasks {
		m[taskName] = upfTasks.Spec
	}
	return m
}

func GetUpffilePathsMap() map[string]upffilepath {
	m := make(map[string]upffilepath)
	for pathName, upfFilePath := range config.Upffilepath {
		m[pathName] = upfFilePath
	}
	return m
}

func GetDtfilepathsMap() map[string]dtfilepath {
	m := make(map[string]dtfilepath)
	for pathName, dtFilePath := range config.Dtfilepath {
		m[pathName] = dtFilePath
	}
	return m
}

func GetInttfilepathsMap() map[string]inttfilepath {
	m := make(map[string]inttfilepath)
	for pathName, inttfilepath := range config.Inttfilepath {
		m[pathName] = inttfilepath
	}
	return m
}

func GetUpfTask(taskName string) string {
	return GetUpfTasksMap()[taskName]
}

func GetUpffilePath(pathname string) upffilepath {
	return GetUpffilePathsMap()[pathname]
}

func GetInttfilepath(pathname string) inttfilepath {
	return GetInttfilepathsMap()[pathname]
}

func GetDataSourceName() string {
	return config.Mysql.DataSourceName
}

func GetMaxOpenConn() int {
	return config.Mysql.MaxOpenConn
}

func GetMaxIdleConn() int {
	return config.Mysql.MaxIdleConn
}

func GetAsserver() string {
	return config.Aerospike.Asserver
}

func GetNamespase() string {
	return config.Aerospike.Namespase
}

func GetAsPort() int {
	return config.Aerospike.Port
}

func main() {
	m := GetUpfTasksMap()
	fmt.Println(m["TagViewAdvClick"])

	m1 := GetUpffilePathsMap()
	fmt.Println(m1["UserProfileCr"].Imei)

	//m2 := GetDtfilepathsMap()
	fmt.Println(GetDtfilepathsMap()["intt"].Filepath)

	fmt.Println(config.Title)
	fmt.Println(config.Mysql.DataSourceName)
	fmt.Println(config.Mysql.MaxOpenConn)
	fmt.Println(config.Mysql.MaxIdleConn)
	fmt.Println(config.Aerospike.Asserver)
}
