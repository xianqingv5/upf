package mysql

import (
	"database/sql"
	"fmt"
	"upf/config"
	. "upf/error"
	"upf/utils/date"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB

func init() {
	fmt.Println("mysql init")
	db, _ = sql.Open("mysql", config.GetDataSourceName())
	db.SetMaxOpenConns(config.GetMaxOpenConn())
	db.SetMaxIdleConns(config.GetMaxIdleConn())
	db.Ping()
}

//
func InsertInttAdn(genint string, uc int) {
	stmt, err := db.Prepare(`INSERT user_profile_intt_adn (genint_id,usercover,date) values (?,?,?)`)
	PanicOnError(err)
	res, err := stmt.Exec(genint, uc, date.GetYesDate())
	PanicOnError(err)
	id, err := res.LastInsertId()
	PanicOnError(err)
	fmt.Println(id)
}

func InsertAdvClick(advId string, uc int) {
	stmt, err := db.Prepare(`INSERT user_profile_adv_click (advertiser,tagname,usercover,date) values (?,?,?,?)`)
	PanicOnError(err)
	res, err := stmt.Exec(advId, "点击重定向", uc, date.GetYesDate())
	PanicOnError(err)
	id, err := res.LastInsertId()
	PanicOnError(err)
	fmt.Println(id)
}

// 根据日期得到所有的通用兴趣相关的标签数据
func GetUserProfileInttAdnByDate(sdate string) map[string]int {
	rows, err := db.Query("select genint_id, usercover from user_profile_intt_adn where `date`='" + sdate + "'")
	PanicOnError(err)
	m := make(map[string]int)
	for rows.Next() {
		var genint_id string
		var usercover int
		err = rows.Scan(&genint_id, &usercover)
		PanicOnError(err)
		m[genint_id] = usercover
	}
	return m
}

// 根据通用兴趣id更新通用兴趣相关的标签数据（加入adview adx渠道的数据）
func UpdateUserProfileInttAdnByG2id(count int, g2id string, date string) {
	stmt, err := db.Prepare(`update user_profile_intt_adn set usercover = ? where genint_id = ? and date = ?`)
	PanicOnError(err)
	res, err := stmt.Exec(count, g2id, date)
	PanicOnError(err)
	num, err := res.RowsAffected()
	PanicOnError(err)
	fmt.Println(num)
}
