package utils

import (
	"crypto/md5"
	"crypto/sha1"
	"fmt"
	"io"
	"strings"
)

// 对字符串进行MD5哈希
func Md5(data string) string {
	t := md5.New()
	io.WriteString(t, data)
	return fmt.Sprintf("%x", t.Sum(nil))
}

// 对字符串进行SHA1哈希
func Sha1(data string) string {
	t := sha1.New()
	io.WriteString(t, data)
	return fmt.Sprintf("%x", t.Sum(nil))
}

func GetEncryptionKey(myset string, key string) string {
	return func(myset string, key string) string {
		if myset == "adnuser" || myset == "mwuser" {
			return key
		} else if myset == "md5user" {
			return strings.ToUpper(Md5(key))
		} else if myset == "sha1user" {
			return Sha1(key)
		} else if myset == "ykuser" || myset == "qquser" || myset == "waxuser" {
			return strings.ToUpper(key)
		}
		return ""
	}(myset, key)
}
