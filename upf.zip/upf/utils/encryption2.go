package utils

import (
	"crypto/md5"
	"crypto/sha1"
	"fmt"
	"io"
)

// 对字符串进行MD5哈希
func C(data string) string {
	t := md5.New()
	io.WriteString(t, data)
	return fmt.Sprintf("%x", t.Sum(nil))
}

// 对字符串进行SHA1哈希
func D(data string) string {
	t := sha1.New()
	io.WriteString(t, data)
	return fmt.Sprintf("%x", t.Sum(nil))
}
