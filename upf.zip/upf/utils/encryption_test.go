package utils_test

import (
	"fmt"
	"testing"
	"upf/utils"
)

func TestMd5(t *testing.T) {
	m := utils.Md5("aa")
	if m != "" {
		fmt.Println(m)
	}
}

func TestSha1(t *testing.T) {
	m := utils.Sha1("aa")
	if m != "" {
		fmt.Println(m)
	}
}
