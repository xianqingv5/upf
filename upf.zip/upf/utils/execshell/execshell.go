package main

import (
	"fmt"
	"os/exec"
	"strings"
)

func ExecShell() {
	//执行【ls /】并输出返回文本
	f, err := exec.Command("ls", "/").Output()
	if err != nil {
		fmt.Println(err.Error())
	}
	fmt.Println(string(f))
}

func main() {
	f, err := exec.Command("/bin/sh", "test.sh").Output()
	if err != nil {
		fmt.Println(err.Error())
	}

	fmt.Println(strings.Split(string(f), "\n")[1])
	// fmt.Print(string(f))
}
