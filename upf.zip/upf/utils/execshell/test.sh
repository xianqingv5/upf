#!/bin/bash
/usr/local/mysql/bin/mysql -uroot -hlocalhost -padmin smp --default-character-set=utf8 -e "select count(0) from yiche_app_app_leads_channel_day"