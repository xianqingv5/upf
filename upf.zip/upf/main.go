package main

import (
	"flag"
	"fmt"
	"strconv"
	"strings"
	"upf/config"
	"upf/user_profile_cr"
	"upf/user_profile_intt/adview"
	"upf/user_profile_intt/tanx"
	"upf/user_profile_intt/youku"
	"upf/userprofile/ct"
	rsr "upf/userprofile/rsr"
	"upf/utils"
	"upf/utils/date"
	"upf/utils/mysql"

	"github.com/Sirupsen/logrus"
	"github.com/robfig/cron"
)

var log = logrus.New()

func init() {
	log.Formatter = new(logrus.JSONFormatter)
	log.Formatter = new(logrus.TextFormatter) // default
	log.Level = logrus.DebugLevel
}

func InsertDb_AdvClick(line string) {
	if line != "" {
		dat := strings.Split(line, "\t")
		if dat[0] != "^" {
			b, _ := strconv.Atoi(dat[1])
			mysql.InsertAdvClick(dat[0], b)
		}
	}
}

func InsertDb_InttAdn(line string) {
	if line != "" {
		dat := strings.Split(line, "\t")
		if dat[0] != "^" {
			b, _ := strconv.Atoi(dat[1])
			mysql.InsertInttAdn(dat[0], b)
		}

	}
}

func InsertDb_InttAdn_Count(line string) {
	if line != "" {
		b, _ := strconv.Atoi(line)
		mysql.InsertInttAdn("0", b)
	}
}

func TagViewAdvClick() {
	rq := date.GetYesDate()

	// 标签可视化 广告主定向
	fileName := config.GetUserProfileCr() + "/adv_click_" + rq + ".dat"
	if utils.IsExist(fileName) {
		if size, _ := utils.FileSize(fileName); size > 0 {
			utils.ReadLine(fileName, InsertDb_AdvClick)
		}
	} else {
		fmt.Println(fileName + " is not exist!")
	}
}

func TagViewInttAdn() {
	rq := date.GetYesDate()

	// 标签可视化 通用兴趣
	fileName1 := config.GetUserProfileIntt() + "/intt_adn_" + rq + ".dat"
	fileName2 := config.GetUserProfileIntt() + "/intt_adn_count_" + rq + ".dat"
	if utils.IsExist(fileName1) {
		if size, _ := utils.FileSize(fileName1); size > 0 {
			utils.ReadLine(fileName1, InsertDb_InttAdn)
		}
	} else {
		log.Info(fileName1 + " is not exist!")
	}

	if utils.IsExist(fileName2) {
		if size, _ := utils.FileSize(fileName2); size > 0 {
			utils.ReadLine(fileName2, InsertDb_InttAdn_Count)
		}
	} else {
		log.Info(fileName2 + " is not exist!")
	}
}

func main() {
	idc := flag.String("idc", "bj", "default idc is beijing")
	m := flag.String("m", "", "manual control")
	flag.Parse()

	log.Info("UserProfileCr=" + config.GetUpfTask("UserProfileCr"))
	log.Info("TagViewAdvClick=" + config.GetUpfTask("TagViewAdvClick"))
	log.Info("TagViewInttAdn=" + config.GetUpfTask("TagViewInttAdn"))
	log.Info("UserProfileInttAdxAdview=" + config.GetUpfTask("UserProfileInttAdxAdview"))
	log.Info("UserProfileCrAdxYouku=" + config.GetUpfTask("UserProfileCrAdxYouku"))
	log.Info("Rsr=" + config.GetUpfTask("Rsr"))
	log.Info("Ct=" + config.GetUpfTask("Ct"))

	if *m == "" {
		if *idc == "bj" { // 北京机房
			log.WithFields(logrus.Fields{"idc": "beijing"}).Info("this is beijing idc.")
			c := cron.New()
			c.AddFunc(config.GetUpfTask("UserProfileCr"), user_profile_cr.UserProfileCr)
			c.AddFunc(config.GetUpfTask("TagViewAdvClick"), TagViewAdvClick)
			c.AddFunc(config.GetUpfTask("UserProfileInttAdxAdview"), adview.UserProfileInttAdxAdview)
			c.AddFunc(config.GetUpfTask("UserProfileCrAdxYouku"), youku.InttAdnYouku)
			c.AddFunc(config.GetUpfTask("Rsr"), rsr.Rsr)
			c.AddFunc(config.GetUpfTask("TagViewAdview"), adview.TagViewAdview)                 // 把adx adview数据加到标签可视化中
			c.AddFunc(config.GetUpfTask("TagViewYouku"), youku.TagViewYouku)                    // 把adx youku数据加到标签可视化中
			c.AddFunc(config.GetUpfTask("TagViewTanx"), tanx.TagViewTanx)                       // 把adx tanx数据加到标签可视化中
			c.AddFunc(config.GetUpfTask("Ct"), ct.UserProfileCtBeiJing)                         // 转化重定向
			c.AddFunc(config.GetUpfTask("UserProfileInttAdxTanx"), tanx.UserProfileInttAdxTanx) // adx tanx通用兴趣
			c.Start()
			select {}
		} else if *idc == "wx" { // 无锡机房
			log.WithFields(logrus.Fields{"idc": "wuxi"}).Info("this is wuxi idc.")
			c := cron.New()
			c.AddFunc(config.GetUpfTask("TagViewInttAdn"), TagViewInttAdn)
			c.AddFunc(config.GetUpfTask("Ct"), ct.UserProfileCtWuXi) // 转化重定向
			c.Start()
			select {}
		}
	} else {
		if *m == "1" { // 通用兴趣标签可视化
			TagViewInttAdn()
		} else if *m == "2" { // 广告主点击标签可视化
			TagViewAdvClick()
		} else if *m == "3" { // adview通用兴趣匹配
			adview.UserProfileInttAdxAdview()
		} else if *m == "4" { // adn点击重定向
			user_profile_cr.UserProfileCr()
		} else if *m == "5" { // 把adx adview数据加到标签可视化中
			adview.TagViewAdview()
		} else if *m == "6" { // 把adx youku数据加到标签可视化中
			youku.TagViewYouku()
		} else if *m == "7" { // youku通用兴趣匹配
			youku.InttAdnYouku()
		} else if *m == "8" { // rsr
			rsr.Rsr()
		} else if *m == "9" { // ct beijing
			ct.UserProfileCtBeiJing()
		} else if *m == "10" {
			ct.UserProfileCtWuXi()
		} else if *m == "11" { // tanx通用兴趣匹配
			tanx.UserProfileInttAdxTanx()
		} else if *m == "12" { // 把adx tanx数据加到标签可视化中
			tanx.TagViewTanx()
		}
	}

}
