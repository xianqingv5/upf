#!/bin/bash
source ~/.bash_profile
source /data/hadoop/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi
echo $DAY

USERDIR="/data/hadoop/analysis/userprofile/user_profile_gr"

log(){
        echo "`date +%Y%m%d-%H%M%S` :  $@"
}

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/imei_tmp/*
rm -rf ${USERDIR}/output/idfa_tmp/*

log " exec imei user_id -> app_pkg "
/data/hadoop/hive/bin/hive -S -e "select distinct t1.user_id from (select request_id,imei as user_id,app_pkg from app_device where day_id='${DAY}' and os=1 and imei <>'\^' and imei<>'0' and imei<>'000000000000000' and imei<>'0000000000000000' and imei <>'111111111111111' and imei<>'00000000' and imei<>'00000000000000' and imei<>'Unknown' and imei is not null and imei<>'' )  t1 join ( select app_pkg,request_id from app_install where  day_id='${DAY}' and app_pkg in ('com.meitu.meipaimv','com.meitu.meiyancamera','com.txkeifired.model','com.mt.mtxx.mtxx','com.pixslr.petpperslr','name.rnmgpvju.hijtks.prvs','com.picodaquan.xzwkomma','com.idddx.lwp.mogujie.shenxiaoxiang','com.duitang.main','com.achievo.vipshop','com.mogujie','com.wangzhi.MaMaMall','com.meilishuo','com.yourdream.app.android','com.lingan.fitness','gov.rgmipv.ighjkq.kh','com.ada.app.dayima','com.mnying.healthsay','com.lingan.seeyou','com.lingan.yunqi','com.wangzhi.MaMaHelp','com.buykee.princessmakeup','cn.happyzhuomian.tmflykw')) t2 on t1.request_id=t2.request_id ;" > ${USERDIR}/output/imei/imei-${DAY}.dat

#log " exec idfa user_id -> app_pkg "
#/data/hadoop/hive/bin/hive -S -e "select distinct idfa from rela_clk_limit_ios where day_id='${DAY}' and advertiser_id in (45,39,28,26,36);" > ${USERDIR}/output/idfa/idfa-${DAY}.dat
log " hive exec end "

#把数据导入hive中
/data/hadoop/hive/bin/hive -S -e "load data local inpath '${USERDIR}/output/imei/imei-${DAY}.dat' into table base_gender PARTITION(day_id=${DAY}) ;"
#/data/hadoop/hive/bin/hive -S -e "load data local inpath '/home/madfuhaijun/analysis/userprofile/user_profile_gr/output/idfa/idfa-${DAY}.dat' into table base_gender PARTITION(day_id=${DAY}) ;"

cp ${USERDIR}/output/imei/imei-${DAY}.dat ${USERDIR}/output/imei_tmp
#cp ${USERDIR}/output/idfa/idfa-${DAY}.dat ${USERDIR}/output/idfa_tmp
cd ${USERDIR}/output/imei_tmp
split -l 10000 ${USERDIR}/output/imei_tmp/imei-${DAY}.dat
#cd ${USERDIR}/output/idfa_tmp
#split -l 10000 ${USERDIR}/output/idfa_tmp/idfa-${DAY}.dat

rm -rf ${USERDIR}/output/imei_tmp/imei-${DAY}.dat
#rm -rf ${USERDIR}/output/idfa_tmp/idfa-${DAY}.dat

#adnuser
go run ${USERDIR}/user_profile_gr2.go -type=1
#mwuser
go run ${USERDIR}/user_profile_gr2.go -type=2
#md5user
go run ${USERDIR}/user_profile_gr2.go -type=3
#sha1user
go run ${USERDIR}/user_profile_gr2.go -type=4


imeicount=`cat ${USERDIR}/output/imei/imei-${DAY}.dat | wc -l`
#idfacount=`cat ${USERDIR}/output/idfa/idfa-${DAY}.dat | wc -l`
idfacount=0
allcount=`expr ${imeicount} + ${idfacount}`
/data/mysql/mysql/bin/mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; insert into shell_exec_gr_log (shell_name,exec_time,exec_status,inc_capacity,inc_capacity_imei,inc_capacity_idfa) values ('user_profile_gr',now(),'Y',${allcount}, ${imeicount}, ${idfacount});"

/usr/bin/rsync -zrtopgl --bwlimit=8000 --progress ${USERDIR}/output/imei/imei-${DAY}.dat 211.151.64.233::userprofile/user_profile_gr/output/imei