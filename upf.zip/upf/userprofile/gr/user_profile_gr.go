//user_profile_insat
package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"runtime"
	"strings"
	"upf/utils"

	. "github.com/aerospike/aerospike-client-go"
)

var asserver = "192.168.32.11"
var port = 3000
var namespase = "upf"

func ReadLine(fileName string, handler func(string, *Client, string) string, ch chan int, i int, myset string) error {

	f, err := os.Open(fileName)
	if err != nil {
		return err
	}

	client, err := NewClient(asserver, port)

	if err != nil {
		return err
	}

	buf := bufio.NewReader(f)

	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ret := handler(line, client, myset)
		if ret == "end" || ret == "err" || ret == "MO" {
			break
		}
		if err != nil {
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
	ch <- i
	return nil
}

func panicOnError(err error) {
	if err != nil {
		panic(err)
	}
}

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		//dat := strings.Split(line, "\t")
		key, err := NewKey(namespase, myset, line)
		if err != nil {
			return "err"
		}

		gr := NewBin("gr", "f")
		err = client.PutBins(nil, key, gr)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

func execGrAdn(filepath string, myset string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go ReadLine(filepath+"/"+files[i].Name(), execFile, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func main() {

	type2 := flag.String("type", "1", "default adn is 1")
	flag.Parse()

	filepath := "/data/hadoop/analysis/userprofile/user_profile_gr/output/imei_tmp"
	//filepath_idfa := "/home/madfuhaijun/analysis/userprofile/user_profile_gr/output/idfa_tmp"
	//filepath_idfa := "E:\\tmp\\gr_idfa"
	//filepath := "E:\\tmp\\gr"
	if *type2 == "1" { //adnuser
		myset := "adnuser"
		execGrAdn(filepath, myset)
		//execGrAdn(filepath_idfa, myset)
	} else if *type2 == "2" { //mwuser
		myset := "mwuser"
		execGrAdn(filepath, myset)
		//execGrAdn(filepath_idfa, myset)
	} else if *type2 == "3" { //md5user
		myset := "md5user"
		execGrAdnMd5(filepath, myset)
	} else if *type2 == "4" { //sha1user
		myset := "sha1user"
		execGrAdnSHA1(filepath, myset)
	}
}

//---------------------------MD5----------------------------------
func execGrAdnMd5(filepath string, myset string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go ReadLineMd5(filepath+"/"+files[i].Name(), execFileMd5, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func ReadLineMd5(fileName string, handler func(string, *Client, string) string, ch chan int, i int, myset string) error {

	f, err := os.Open(fileName)
	if err != nil {
		return err
	}

	client, err := NewClient(asserver, port)

	if err != nil {
		return err
	}

	buf := bufio.NewReader(f)

	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ret := handler(line, client, myset)
		if ret == "end" || ret == "err" || ret == "MO" {
			break
		}
		if err != nil {
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
	ch <- i
	return nil
}

func execFileMd5(line string, client *Client, myset string) string {
	if line != "" {
		//dat := strings.Split(line, "\t")
		fmt.Println(strings.ToUpper(utils.Md5(line)))
		key, err := NewKey(namespase, myset, strings.ToUpper(utils.Md5(line)))
		if err != nil {
			return "err"
		}

		gr := NewBin("gr", "f")
		err = client.PutBins(nil, key, gr)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

//-------------------------md5--------------------------------------------------

//---------------------------Sha1----------------------------------
func execGrAdnSHA1(filepath string, myset string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go ReadLineMd5(filepath+"/"+files[i].Name(), execFileSHA1, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func ReadLineSHA1(fileName string, handler func(string, *Client, string) string, ch chan int, i int, myset string) error {

	f, err := os.Open(fileName)
	if err != nil {
		return err
	}

	client, err := NewClient(asserver, port)
	//panicOnError(err)
	if err != nil {
		return err
	}

	buf := bufio.NewReader(f)

	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ret := handler(line, client, myset)
		if ret == "end" || ret == "err" || ret == "MO" {
			break
		}
		if err != nil {
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
	ch <- i
	return nil
}

func execFileSHA1(line string, client *Client, myset string) string {
	if line != "" {
		fmt.Println(utils.Sha1(line))
		key, err := NewKey(namespase, myset, utils.Sha1(line))
		if err != nil {
			return "err"
		}

		gr := NewBin("gr", "f")
		err = client.PutBins(nil, key, gr)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

//-------------------------md5--------------------------------------------------
