//user_profile_rsr
package rsr

import (
	"fmt"
	. "upf/config"
	common "upf/user_profile_common"
	"upf/utils"

	. "github.com/aerospike/aerospike-client-go"
)

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		fmt.Println(line)
		key, err := NewKey(GetNamespase(), myset, utils.GetEncryptionKey(myset, line))
		if err != nil {
			return "err"
		}

		spr := NewBin("rsr", "1")
		err = client.PutBins(nil, key, spr)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

func Rsr() {

	filepath := GetDtfilepathsMap()["rsr"].Filepath + "/rsr_tmp"
	//"/home/madfuhaijun/analysis/userprofile/user_profile_rsr/output/rsr_tmp"
	myset := "adnuser"
	common.ExecPROCS(filepath, myset, execFile)

	myset = "mwuser"
	common.ExecPROCS(filepath, myset, execFile)

	myset = "md5user"
	common.ExecPROCS(filepath, myset, execFile)

	myset = "sha1user"
	common.ExecPROCS(filepath, myset, execFile)
}
