#!/bin/bash
source ~/.bash_profile
source /data/hadoop/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

echo $DAY

USERDIR="/data/hadoop/analysis/userprofile/user_profile_spr"

log(){
        echo "`date +%Y%m%d-%H%M%S` :  $@"
}

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/spr_tmp/*


log " exec android imei "

/data/hadoop/hive/bin/hive -S -e "select distinct imei from app_device where (model like '%IPHONE%' or model like '%N9200%' or model like '%VERTU%' or model like '%GEMRY%' or model like '%VEB%' or model like '%XP7700%' or model like '%G9280%' or model like '%E6883%' or model like '%N9200%' or model like '%Xperia%' or model like '%Passport%' or model like '%Watch%' or model like '%E6533%' or model like '%FansPhone%' or model like '%OUGU%' or model like '%SS136%' or model like '%D6683%' or model like '%PRO5%' or model like '%SM%G9198%' or model like '%SM%W2015%' or model like '%BlackBerry%P9983%' or model like '%VEB%W1%' or model like '%6S%Plus%' or model like '%SM%S6%' or model like '%BlackBerry%Priv%' or model like '%DATANG%T98%' or model like '%SONY%Z5%' or model like '%LG%V10%' or model like '%HUAWEI%Mate%S%' or model like '%HUAWEI%P7%' or model like '%HUAWEI%Nexus%' or model like '%HUAWEI%MATE%' or model like '%Philips%V989%' or model like '%GiONEE%E8%' or model like '%SONY%Z3%' or model like '%SONY%E6533Z3+%' or model like '%ZTE%AXON%' or model like '%LG%Nexus%' or model like '%HTC%ONEA9%' or model like '%Meitu%V4%' or model like '%SUGAR%SS129%' or model like '%SM%A8000%' or model like '%HTC%M9pt%' or model like '%Greenorange%VOGA%' or model like '%MI%Note%' or model like '%CAT%S50%' or model like '%Moto%X%' or model like '%sonim%BTH%' or model like '%GiONEE%W900%' or model like '%Motorola%XT1115%' or model like '%OPPO%R7%Plus%' or model like '%HUAWEI%P8%' or model like '%Caterpillar%S40%' or model like '%HUAWEI%Ascend%') and os=1 and day_id='${DAY}' and imei != '';" > ${USERDIR}/output/spr/spr_${DAY}.dat

log " hive exec end "

cp ${USERDIR}/output/spr/spr_${DAY}.dat ${USERDIR}/output/spr_tmp
cd ${USERDIR}/output/spr_tmp
split -l 10000 ${USERDIR}/output/spr_tmp/spr_${DAY}.dat
rm -rf ${USERDIR}/output/spr_tmp/spr_${DAY}.dat

#adnuser
go run ${USERDIR}/user_profile_spr.go -type=1
#mwuser
go run ${USERDIR}/user_profile_spr.go -type=2
#md5user
go run ${USERDIR}/user_profile_spr.go -type=3
#sha1user
go run ${USERDIR}/user_profile_spr.go -type=4

log " import aerospike end "

imeicount=`cat ${USERDIR}/output/spr/spr_${DAY}.dat | wc -l`
idfacount=0
allcount=`expr ${imeicount} + ${idfacount}`
/data/mysql/mysql/bin/mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; insert into shell_exec_spr_log (shell_name,exec_time,exec_status,inc_capacity,inc_capacity_imei,inc_capacity_idfa) values ('user_profile_spr',now(),'Y',${allcount}, ${imeicount}, ${idfacount});"

/usr/bin/rsync -zrtopgl --bwlimit=8000 --progress /data/hadoop/analysis/userprofile/user_profile_spr/output/spr/spr_${DAY}.dat 211.151.64.233::userprofile/user_profile_spr/output/spr
