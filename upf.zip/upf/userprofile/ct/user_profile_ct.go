package ct

import (
	"fmt"
	"os/exec"
	"strings"
	. "upf/config"
	. "upf/user_profile_common"
	"upf/utils"
	"upf/utils/date"

	. "github.com/aerospike/aerospike-client-go"
)

func UserProfileCtWuXi() {
	fileName := "/data/hadoop/analysis/userprofile/user_profile_ct/output/ct_tmp/ct" + date.GetYesDate() + "-90.log"
	filePath := "/home/madfuhaijun/analysis/userprofile/user_profile_ct/output/ct_tmp"
	if utils.IsExist(fileName) {
		goto A
	} else {
		cmd := exec.Command("/bin/sh", "/data/hadoop/analysis/userprofile/user_profile_ct/user_profile_ct.sh")
		b2, err := cmd.Output()
		if err != nil {
			panic(err)
		} else {
			println(string(b2[:len(b2)]))
			goto A
		}
	}

A:
	{
		// adnuser
		myset := "adnuser"
		ExecPROCS(filePath, myset, execFile)
	}
}

func UserProfileCtBeiJing() {
	fileName := "/home/madfuhaijun/analysis/userprofile/user_profile_ct/output/ct_tmp/ct" + date.GetYesDate() + "-90.log"
	filePath := "/home/madfuhaijun/analysis/userprofile/user_profile_ct/output/ct_tmp"
	if utils.IsExist(fileName) {
		goto A
	} else {
		cmd := exec.Command("/bin/sh", "/home/madfuhaijun/analysis/userprofile/user_profile_ct/user_profile_ct.sh")
		b2, err := cmd.Output()
		if err != nil {
			panic(err)
		} else {
			println(string(b2[:len(b2)]))
			goto A
		}
	}

A:
	{
		// adnuser
		myset := "adnuser"
		ExecPROCS(filePath, myset, execFile)
	}
}

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")
		fmt.Println(utils.GetEncryptionKey(myset, dat[0]))
		key, err := NewKey(GetNamespase(), myset, utils.GetEncryptionKey(myset, dat[0]))
		if err != nil {
			return "err"
		}

		ct := NewBin("ct", dat[1])
		err = client.PutBins(nil, key, ct)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}
