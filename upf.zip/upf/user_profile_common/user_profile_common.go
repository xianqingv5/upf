package user_profile_common

import (
	"bufio"
	"io"
	"io/ioutil"
	"os"
	"runtime"
	"strings"
	"upf/config"

	. "github.com/aerospike/aerospike-client-go"
)

func ExecPROCS(filepath string, myset string, execFile func(string, *Client, string) string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go ReadLine(filepath+"/"+files[i].Name(), execFile, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func ReadLine(fileName string, handler func(string, *Client, string) string, ch chan int, i int, myset string) error {

	f, err := os.Open(fileName)
	if err != nil {
		return err
	}

	client, err := NewClient(config.GetAsserver(), config.GetAsPort())
	if err != nil {
		return err
	}

	buf := bufio.NewReader(f)

	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ret := handler(line, client, myset)
		if ret == "end" || ret == "err" || ret == "MO" {
			break
		}
		if err != nil {
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
	ch <- i
	return nil
}
