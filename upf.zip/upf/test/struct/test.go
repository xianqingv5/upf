package main

import (
	"fmt"
	"os"
)

/*
1). 使用 type 和 struct 定义结构体；和 c 的类似，结构体是对数据的封装，就是一个容器，里面放一些东东；
2). 结构体中类型声明和普通的一致，先写名字，再写类型；
3). 构造一个结构体值，或是对象，或叫实例，直接名字加参数值即可；
4). 结构体值可以 fmt.Println 直接输出；
5). 实际上可以看出来 go 声明或是定义东西的风格：先说明这是神马玩意，然后是名字，然后具体类型是神马东东；比如变量声明 var a int ，比如函数声明 func add(a int, b int) int ，比如结构体 type Point struct{ x, y int} ；
*/
type Vertex struct {
	X int
	Y int
}

type Student struct {
	name  string
	id    int
	score uint
}

func main2() {
	xy := &Vertex{}
	fmt.Println(xy)
	fmt.Println(*xy)
	xy.X = 100
	fmt.Println(&xy.X)
	fmt.Println(string(os.PathListSeparator))

	fmt.Println("---------------------------")

	v := Vertex{1, 2}
	v.X = 4
	fmt.Println(v)

	fmt.Println("---------------------------")
	p := Vertex{1, 2}
	q := &p
	q.X = 10
	(*q).Y = 20
	r := &q
	s := &r
	(**s).Y = 30

	fmt.Println(p, q, r, s, *q, *r, *s, **r, **s, ***s)

	fmt.Println("---------------------------")
	v1 := new(Vertex2) // new构造结构体，返回指针；new 的同时貌似不能初始化，new 是个函数。
	fmt.Println(v1)

}

type Vertex2 struct {
	Lat, Long float64
}

type Vertex3 struct {
	Lat, Long float64
}

var m map[string]Vertex3

func main() { // map 中的 nil 表示为空，不能被赋值; make 函数构造 map，貌似不能通过 new
	m = make(map[string]Vertex3)
	m["Bell Labs"] = Vertex3{
		40.68433, 74.39967,
	}
	m["abc"] = Vertex3{
		1.2, 3.4,
	}
	fmt.Println(m["abc"])
}
