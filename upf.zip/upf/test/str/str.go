package main

import (
	"unsafe"
)

func main() {
	s := "abcdefg"
	println(unsafe.Sizeof(s), len(s))
}
