package main

/*
  http://studygolang.com/articles/3314
*/
import (
	"fmt"
)

func funcName(a interface{}) string {
	value, ok := a.(string)
	if !ok {
		fmt.Println("It's not ok for type string")
		return ""
	}
	fmt.Println("The value is ", value)
	return value
}

func main() {
	var t interface{}
	t = 123456
	switch t := t.(type) {
	default:
		fmt.Printf("unexpected type %T", t) // %T prints whatever type t has
	case bool:
		fmt.Printf("boolean %t\n", t) // t has type bool
	case int:
		fmt.Printf("integer %d\n", t) // t has type int
	case *bool:
		fmt.Printf("pointer to boolean %t\n", *t) // t has type *bool
	case *int:
		fmt.Printf("pointer to integer %d\n", *t) // t has type *int
	}
}

/*
1）如果不符合要求可以尽快的return（return as fast as you can），而减少else语句的使用，这样可以更加直观一些。
2）转换类型的时候如果是string可以不用断言，使用fmt.Sprint()函数可以达到想要的效果
3）变量的定义和申明可以用组的方式
4) 函数逻辑比较复杂，可以把一些逻辑封装成一个函数，提高可读性。
5）使用net/http包和net/url包的函数，可能会带有url encode功能，需要注意。
*/
