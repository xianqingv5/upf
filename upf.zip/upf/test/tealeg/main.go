package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
	"github.com/tealeg/xlsx"
)

func PanicOnError(err error) {
	if err != nil {
		panic(err)
	}
}

func main() {

	db, err := sql.Open("mysql", "admin:TH)6*Ca($.$u5)kA)bb+X%k[$wWY45@tcp(211.151.64.236:3306)/category?charset=utf8")
	PanicOnError(err)
	stmt, err := db.Prepare(`INSERT into mp_brand_target(b_m_log, brand, model) VALUES (?,?,?)`)
	PanicOnError(err)

	excelFileName := "/Users/qingfeng/Downloads/ios.xlsx"
	xlFile, err := xlsx.OpenFile(excelFileName)
	if err != nil {
		fmt.Println(err)
	}
	for _, sheet := range xlFile.Sheets {
		/*if sheet.Name != "OPPO" {
			fmt.Println(sheet.Name)
			for _, row := range sheet.Rows {
				//for _, cell := range row.Cells {
				fmt.Println(row.Cells[0].Value)
				fmt.Println(row.Cells[1].Value)
				fmt.Println(row.Cells[2].Value)
				//}
				fmt.Println("----------------------")

				res, err := stmt.Exec(row.Cells[0].Value, row.Cells[1].Value, row.Cells[2].Value)
				PanicOnError(err)
				num, err := res.RowsAffected()
				PanicOnError(err)
				fmt.Println(num)
			}
		}*/

		if sheet.Name == "ios" {
			for _, row := range sheet.Rows {
				if row.Cells[0].Value != "编号" && row.Cells[0].Value != "id" {
					res, err := stmt.Exec(row.Cells[1].Value, row.Cells[2].Value, row.Cells[3].Value)
					PanicOnError(err)
					num, err := res.RowsAffected()
					PanicOnError(err)
					fmt.Println(num)

					fmt.Println(row.Cells[1].Value)
					fmt.Println(row.Cells[2].Value)
					fmt.Println(row.Cells[3].Value)
					//}
					fmt.Println("----------------------")
				}

			}
		}

	}
}
