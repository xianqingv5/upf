package main

import (
	"fmt"
	"upf/lib"
	"upf/utils"
)

func main() {
	lib.Hello()
	ss := utils.Md5("ddd")
	dd := utils.C("sss")
	fmt.Println(ss)
	fmt.Println(dd)
}
