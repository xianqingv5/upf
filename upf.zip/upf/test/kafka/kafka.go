package main

import (
	"bufio"
	"log"
	"os"
	"strings"

	"fmt"
	"github.com/optiopay/kafka"
	"github.com/optiopay/kafka/proto"
)

const (
	topic     = "adLogV2"
	partition = 6
)

var kafkaAddrs = []string{"madwx21:9092", "madwx61:9092", "madwx71:9092"}

// printConsumed read messages from kafka and print them out 消息消费
func printConsumed(broker kafka.Client) {
	conf := kafka.NewConsumerConf(topic, partition)
	conf.StartOffset = kafka.StartOffsetNewest
	consumer, err := broker.Consumer(conf)
	if err != nil {
		log.Fatalf("cannot create kafka consumer for %s:%d: %s", topic, partition, err)
	}

	for {
		msg, err := consumer.Consume()
		if err != nil {
			if err != kafka.ErrNoData {
				log.Printf("cannot consume %q topic message: %s", topic, err)
			}
			break
		}
		log.Printf("message %d: %s", msg.Offset, msg.Value)
		fmt.Printf("message %d: %s", msg.Offset, msg.Value)
	}
	log.Print("consumer quit")
}

// produceStdin read stdin and send every non empty line as message 消息生产
func produceStdin(broker kafka.Client) {
	producer := broker.Producer(kafka.NewProducerConf())
	input := bufio.NewReader(os.Stdin)
	for {
		line, err := input.ReadString('\n')
		if err != nil {
			log.Fatalf("input error: %s", err)
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		msg := &proto.Message{Value: []byte(line)}
		if _, err := producer.Produce(topic, partition, msg); err != nil {
			log.Fatalf("cannot produce message to %s:%d: %s", topic, partition, err)
			fmt.Printf("cannot produce message to %s:%d: %s", topic, partition, err)
		}
	}
}

func main() {
	// connect to kafka cluster
	fmt.Println("begin")
	broker, err := kafka.Dial(kafkaAddrs, kafka.NewBrokerConf("test-client"))
	if err != nil {
		log.Fatalf("cannot connect to kafka cluster: %s", err)
	}
	defer broker.Close()

	printConsumed(broker)
	//produceStdin(broker)
}
