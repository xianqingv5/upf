package main

import (
	"fmt"

	. "github.com/aerospike/aerospike-client-go"
)

func panicOnError(err error) {
	if err != nil {
		panic(err)
	}
}

func main() {
	// define a client to connect to
	client, err := NewClient("103.37.147.108", 3000)
	panicOnError(err)

	key, err := NewKey("test", "myset", "songhq")
	panicOnError(err)

	// write the bins
	tt3, err3 := client.Execute(nil, key, "updateCr", "updateCr", NewValue("405"))
	if err3 != nil {
		fmt.Println(err3)
	} else {
		fmt.Println(tt3)
	}
	//panicOnError(err)

	// read it back!
	//rec, err := client.Get(nil, key)
	//panicOnError(err)

	//fmt.Printf("%#v\n", *rec)

	// delete the key, and check if key exists
	//existed, err := client.Delete(nil, key)
	//panicOnError(err)
	//fmt.Printf("Record existed before delete? %v\n", existed)
}
