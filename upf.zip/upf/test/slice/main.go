package main

import (
	"fmt"
)

func main() {
	s1 := []int{10, 20, 30, 40, 50}
	fmt.Println(len(s1), cap(s1))

	s2 := s1[1:3]
	fmt.Println(s2)
	fmt.Println(len(s2), cap(s2))

	source := []string{"Apple", "Orange", "Plum", "Banana", "Grape"}
	fmt.Println(source[2:3])
}
