package main

import (
	"fmt"
	"strings"
	"unicode"
)

func Fields(s string) []string {
	return strings.FieldsFunc(s, unicode.IsSpace)
}

func WordCount(s string) map[string]int {
	words := Fields(s) // split words

	ans := make(map[string]int)

	for _, word := range words { // get one word
		_, ok := ans[word] // exist  ?
		if !ok {
			ans[word] = 1
		} else {
			ans[word]++
		}
	}
	return ans
}

func main() {
	fmt.Println(WordCount("sd df sd ssss sd"))
}
