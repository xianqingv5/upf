package main

import (
	"fmt"
	"net/http"
	"reflect"
)

type user struct {
	name string `field:"name" type:"varchar(50)"`
	age  int    `field:"age" type:"int"`
}

type manager struct {
	user
	title string
}

type A int

type B struct {
	A
}

func (A) av()  {}
func (*A) ap() {}
func (B) bv()  {}
func (*B) bp() {}

type V int

func (V) String() string {
	return ""
}

func main() {
	type X int // 真实类型（静态类型）
	type Y int
	var a, b X = 100, 200 // 基础类型（底层类型）
	var c Y = 300

	ta, tb, tc := reflect.TypeOf(a), reflect.TypeOf(b), reflect.TypeOf(c)
	fmt.Println(ta == tb, ta == tc)
	fmt.Println(ta.Name() == tc.Name())
	fmt.Println(ta.Kind() == tc.Kind())

	t := reflect.TypeOf(a)
	fmt.Println(t.Name(), t.Kind())

	// 除通过实际对象获取类型外，也可以直接构造一些基础复合类型
	d := reflect.ArrayOf(10, reflect.TypeOf(byte(0)))
	m := reflect.MapOf(reflect.TypeOf(""), reflect.TypeOf(0))
	fmt.Println(d, m)

	//传入对象应区分基类型和指针类型,因为它们并不属于同一类型
	x := 100
	tx, tp := reflect.TypeOf(x), reflect.TypeOf(&x)
	fmt.Println(tx, tp, tx == tp)
	fmt.Println(tx.Kind(), tp.Kind())
	fmt.Println(tx == tp.Elem()) //方法Elem()返回指针，数组，切片，字典（值）或通道的基类型

	fmt.Println(reflect.TypeOf(map[string]int{}).Elem())
	fmt.Println(reflect.TypeOf([]int32{}).Elem())

	fmt.Println("-------------------------------")

	var mm manager
	t = reflect.TypeOf(&mm)
	if t.Kind() == reflect.Ptr { // 获取指针的基类型
		t = t.Elem()
	}
	for i := 0; i < t.NumField(); i++ {
		f := t.Field(i)
		fmt.Println(f.Name, f.Type, f.Offset)

		if f.Anonymous { // 输出匿名字段结构
			for x := 0; x < f.Type.NumField(); x++ {
				af := f.Type.Field(x)
				fmt.Println(" ", af.Name, af.Type)
			}
		}
	}

	fmt.Println("------------------------")
	// 对于匿名字段，可用多级索引（按定义顺序）直接访问
	t = reflect.TypeOf(mm)
	name, _ := t.FieldByName("name") // 按名称查找
	fmt.Println(name.Name, name.Type)

	age := t.FieldByIndex([]int{0, 1})
	fmt.Println(age.Name, age.Type)

	fmt.Println("-----------------------------")

	var g B
	t = reflect.TypeOf(&g)
	s := []reflect.Type{t, t.Elem()}

	for _, t := range s {
		fmt.Println(t, ":")

		for i := 0; i < t.NumMethod(); i++ {
			fmt.Println(" ", t.Method(i))
		}
	}

	fmt.Println("--------------------")

	var ss http.Server

	t = reflect.TypeOf(ss)
	for i := 0; i < t.NumField(); i++ {
		fmt.Println(t.Field(i).Name)
	}

	fmt.Println("----------------------")

	// 可用反射提取struct tag，还能自动分解。常用于ORM映射，或数据格式验证。
	var u user
	t = reflect.TypeOf(u)
	for i := 0; i < t.NumField(); i++ {
		f := t.Field(i)
		fmt.Println("%s: %s %s\n", f.Name, f.Tag.Get("field"), f.Tag.Get("type"))
	}

	fmt.Println("------------------------")

	var v V
	t = reflect.TypeOf(v)
	// Implements 不能直接使用类型作为参数，导致这用法非常别扭。
	st := reflect.TypeOf((*fmt.Stringer)(nil)).Elem()
	fmt.Println(t.Implements(st))

	it := reflect.TypeOf(0)
	fmt.Println(t.ConvertibleTo(it))
}
