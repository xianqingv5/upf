package main

import (
	"fmt"
)

var t int = 4

func main() {
	if t > 10 {
		goto A
	} else {
		fmt.Println("hhh")
		goto A
	}
A:
	{
		fmt.Println("A")
		//goto C
	}

}
