package main

import (
	"database/sql"
	"fmt"
	"strconv"
	. "upf/error"

	_ "github.com/go-sql-driver/mysql"
)

func main() {
	sdate := "20160831"
	db, err := sql.Open("mysql", "admin:TH)6*Ca($.$u5)kA)bb+X%k[$wWY45@tcp(211.151.64.236:3306)/category?charset=utf8")
	rows, err := db.Query("select genint_id, usercover from user_profile_intt_adn where `date`='" + sdate + "'")
	PanicOnError(err)
	m := make(map[string]int)
	for rows.Next() {
		var genint_id string
		var usercover int
		err = rows.Scan(&genint_id, &usercover)
		PanicOnError(err)
		m[genint_id] = usercover
	}
	fmt.Println(strconv.Itoa(m["5"]))

	/*stmt, err := db.Prepare(`update user_profile_intt_adn set usercover = ? where genint_id = ? and date = ?`)
	PanicOnError(err)
	res, err := stmt.Exec(536546, "0", "20160831")
	PanicOnError(err)
	num, err := res.RowsAffected()
	PanicOnError(err)
	fmt.Println(num)*/
}
