package main

import (
	"fmt"
)

func main() {
	// defer 调用所需参数在 defer 语句执行时就被已计算好了 (拷贝传递)，闭包内则是引用，defer执行顺序FIFO
	x := 1
	defer func(a int) { fmt.Println("a=", a) }(x) //闭包
	defer func() { fmt.Println("x=", x) }()
	x++
}
