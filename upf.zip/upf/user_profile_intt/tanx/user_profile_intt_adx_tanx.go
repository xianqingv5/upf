// tanx
package tanx

import (
	"fmt"
	"strconv"
	"strings"
	. "upf/config"
	. "upf/user_profile_common"
	"upf/utils"
	. "upf/utils/date"
	"upf/utils/mysql"

	. "github.com/aerospike/aerospike-client-go"
)

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")

		key, err := NewKey(GetNamespase(), myset, strings.ToUpper(dat[0]))
		if err != nil {
			return "err"
		}

		tt3, err3 := client.Execute(nil, key, "updateIntt2", "updateIntt", NewValue(dat[1]), NewValue(strings.ToUpper(dat[0])))

		if err3 != nil {
			fmt.Println(err3)
			return "err"
		} else {
			fmt.Println(tt3)
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

func UserProfileInttAdxTanx() {
	filepath := GetInttfilepath("UserProfileInttAdxTanx").Imei
	myset := "adnuser"
	ExecPROCS(filepath, myset, execFile)
	myset = "mwuser"
	ExecPROCS(filepath, myset, execFile)
	myset = "tanxuser"
	ExecPROCS(filepath, myset, execFile)
	filepath = GetInttfilepath("UserProfileInttAdxTanx").Idfa
	myset = "adnuser"
	ExecPROCS(filepath, myset, execFile)
	myset = "mwuser"
	ExecPROCS(filepath, myset, execFile)
	myset = "tanxuser"
	ExecPROCS(filepath, myset, execFile)
}

// 把tanx相关的通用兴趣标签设备数加入标签可视化功能中
func TagViewTanx() {
	// g2_20160831.log
	g2FileName := GetDtfilepathsMap()["intt"].Filepath + "/adx/tanx/g2_" + GetYesDate() + ".log"
	// g2_count20160831.log
	g2CountFileName := GetDtfilepathsMap()["intt"].Filepath + "/adx/tanx/g2_count" + GetYesDate() + ".log"
	if utils.IsExist(g2FileName) && utils.IsExist(g2CountFileName) {
		// 1,读取已有的通用兴趣标签数据
		m := mysql.GetUserProfileInttAdnByDate(GetYesDate())
		if len(m) > 0 { // 必须先有adn相关的数据
			if size, _ := utils.FileSize(g2FileName); size > 0 {
				utils.ReadLine(g2FileName, func(line string) {
					if line != "" {
						dat := strings.Split(line, "\t")
						if m[dat[0]] == 0 { // 原来数据中没有此标签,需要新增
							v, _ := strconv.Atoi(dat[1])
							mysql.InsertInttAdn(dat[0], v)
						} else { // 已经存在,更新
							n, _ := strconv.Atoi(dat[1])
							v := n + m[dat[0]]
							mysql.UpdateUserProfileInttAdnByG2id(v, dat[0], GetYesDate())
						}
					}

				})
			}

			if size, _ := utils.FileSize(g2CountFileName); size > 0 {
				utils.ReadLine(g2CountFileName, func(line string) {
					if m["0"] != 0 {
						if line != "" {
							b, _ := strconv.Atoi(line)
							mysql.UpdateUserProfileInttAdnByG2id(b+m["0"], "0", GetYesDate())
						}
					}
				})
			}
		}
	} else {

	}
}
