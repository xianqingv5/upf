#!/bin/bash
source ~/.bash_profile
source /home/madfuhaijun/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

echo $DAY

USERDIR="/home/madfuhaijun/analysis/userprofile/user_profile_intt"

 log(){
         echo "`date +%Y%m%d-%H%M%S` :  $@"
 }

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/adx_tmp/tanx/imei/*
rm -rf ${USERDIR}/output/adx_tmp/tanx/idfa/*

#从mysql中查询interest_tanx_maping所有数据到本地interest_tanx_maping.dat文件中
mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; select pkname, appname, gen_il_1_id, gen_il_1_name, gen_il_2_id, gen_il_2_name from interest_tanx_maping;" > ${USERDIR}/interest_tanx_maping.dat

log " hive create category table"
#在hive中创建app_im表
hive -S -e " drop table  if exists interest_tanx_maping;
CREATE TABLE if not exists interest_tanx_maping (
pkname STRING,
appname STRING,
gen_il_1_id STRING,
gen_il_1_name STRING,
gen_il_2_id STRING,
gen_il_2_name STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE;" 
#加载interest_tanx_maping.dat中的数据到interest_tanx_maping表
hive -S -e "load data local inpath '${USERDIR}/interest_tanx_maping.dat' into table interest_tanx_maping;"

hive -S -e "select t.imei, CONCAT_WS(',',collect_set(CONCAT(ia.gen_il_2_id, ':1.0'))) from interest_tanx_maping ia left join (SELECT DISTINCT imei,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100006 AND platform='1' AND imei!='' AND imei!='0' AND imei!='000000' AND imei!='00000000' AND imei!='00000000000000' AND imei!='000000000000000' AND imei!='0000000000000000' and app_pkg != '') t on ia.pkname = t.app_pkg group by t.imei;" > ${USERDIR}/output/adx/tanx/tanx_intt_imei_${DAY}.log

hive -S -e "SELECT t.idfa, CONCAT_WS(',',collect_set(CONCAT(ia.gen_il_2_id, ':1.0'))) FROM interest_tanx_maping ia LEFT JOIN (SELECT DISTINCT idfa,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100006 AND platform='2' AND idfa!='' AND idfa != '00000000-0000-0000-0000-000000000000' AND app_pkg != '') t on ia.pkname = t.app_pkg GROUP BY idfa;" > ${USERDIR}/output/adx/tanx/tanx_intt_idfa_${DAY}.log

cp ${USERDIR}/output/adx/tanx/tanx_intt_imei_${DAY}.log ${USERDIR}/output/adx_tmp/tanx/imei
cp ${USERDIR}/output/adx/tanx/tanx_intt_idfa_${DAY}.log ${USERDIR}/output/adx_tmp/tanx/idfa

cd ${USERDIR}/output/adx_tmp/tanx/imei
split -l 50000 ${USERDIR}/output/adx_tmp/tanx/imei/tanx_intt_imei_${DAY}.log
cd ${USERDIR}/output/adx_tmp/tanx/idfa
split -l 50000 ${USERDIR}/output/adx_tmp/tanx/idfa/tanx_intt_idfa_${DAY}.log

rm -rf ${USERDIR}/output/adx_tmp/tanx/imei/tanx_intt_imei_${DAY}.log
rm -rf ${USERDIR}/output/adx_tmp/tanx/idfa/tanx_intt_idfa_${DAY}.log

hive -S -e "insert overwrite table user_profile_day_tanx_inclog partition (day_id='${DAY}')
select t.imei, ia.gen_il_2_id from interest_tanx_maping ia join
(SELECT DISTINCT imei,app_pkg
FROM dmp_request
WHERE day_id = '${DAY}' AND adx_id = 100006 AND platform='1' AND imei!='' AND imei!='0' AND imei!='000000' AND imei!='00000000' AND imei!='00000000000000' AND imei!='000000000000000' AND imei!='0000000000000000' AND app_pkg != '') t ON ia.pkname = t.app_pkg;"

hive -S -e "insert overwrite table user_profile_day_tanx_inclog partition (day_id='${DAY}')
select t.idfa, ia.gen_il_2_id from interest_tanx_maping ia join
(SELECT DISTINCT idfa,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100006 AND platform='2' AND idfa!='' AND idfa != '00000000-0000-0000-0000-000000000000' AND app_pkg != '') t ON ia.pkname = t.app_pkg;"

#得到昨天的昨天（前天）
BDAY=`date -d "${DAY} -1 day " +%Y%m%d`

hive -S -e "insert overwrite table user_profile_day_tanx partition (day_id='${DAY}')
select t.user_id, t.g2 from
(select user_id, g2 from user_profile_day_tanx_inclog where day_id = '${DAY}'
union all
select user_id, g2 from user_profile_day_tanx where day_id = '${BDAY}') t group by t.user_id, t.g2;"

hive -S -e "select g2, count(DISTINCT user_id) from user_profile_day_tanx where day_id = '${DAY}' group by g2;" > ${USERDIR}/output/adx/tanx/g2_${DAY}.log

hive -S -e "select count(distinct user_id) from user_profile_day_tanx where day_id = '${DAY}';" > ${USERDIR}/output/adx/tanx/g2_count${DAY}.log

log " exec end "
