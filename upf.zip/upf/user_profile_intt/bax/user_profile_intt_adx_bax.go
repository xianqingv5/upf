//bax
package bax

import (
	"bufio"
	"bytes"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"runtime"
	"strings"
	"upf/config"
	upfcr "upf/user_profile_cr"

	. "github.com/aerospike/aerospike-client-go"
)

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")
		item := strings.Split(dat[1], ",")
		var buffer bytes.Buffer
		for i := 0; i < len(item); i++ {
			str := getInterestBaxMapping(item[i])

			if str != "" {
				if i == (len(item) - 2) {
					buffer.WriteString(str + ":1.0")
				} else {
					buffer.WriteString(str + ":1.0,")
				}
			}
		}

		key, err := NewKey(config.GetNamespase(), myset, strings.ToUpper(dat[0]))
		if err != nil {
			return "err"
		}

		tt3, err3 := client.Execute(nil, key, "updateIntt2", "updateIntt", NewValue(buffer.String()), NewValue(strings.ToUpper(dat[0])))
		if err3 != nil {
			fmt.Println(err3)
			return "err"
		} else {
			fmt.Println(tt3)
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

func execInttAdxBax(filepath string, myset string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go upfcr.ReadLine(filepath+"/"+files[i].Name(), execFile, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func main() {

	type2 := flag.String("type", "1", "default adn is 1")
	flag.Parse()

	if *type2 == "1" { //imei
		filepath := "/home/madfuhaijun/analysis/userprofile/user_profile_intt/output/adx_tmp/bax/imei"
		myset := "bduser"
		execInttAdxBax(filepath, myset)
	} else if *type2 == "2" { //idfa
		filepath := "/home/madfuhaijun/analysis/userprofile/user_profile_intt/output/adx_tmp/bax/idfa"
		myset := "mwuser"
		execInttAdxBaxIDFA(filepath, myset)
	} else if *type2 == "3" {

	} else if *type2 == "4" {

	}
}

func getInterestBaxMapping(s string) string {
	m2 := map[string]string{
		"1434373635828": "11",
		"1434373677204": "2",
		"1434373720910": "1",
		"1434373754707": "5",
		"1434373814356": "6",
		"1434373872145": "9",
		"1434373902854": "14",
		"1434373940629": "12",
		"1434373976630": "0",
		"1434374034611": "6",
		"1434374066211": "16",
		"1434374101619": "13",
		"1434374133821": "8",
		"1434374169176": "15",
		"1434374218383": "10"}
	return m2[s]
}

//--------------------------bax idfa-----------------------------------------------------
func execInttAdxBaxIDFA(filepath string, myset string) {

	files, _ := ioutil.ReadDir(filepath)

	runtime.GOMAXPROCS(runtime.NumCPU())
	chs := make([]chan int, len(files))
	for i := 0; i < len(files); i++ {
		chs[i] = make(chan int, 1)
		go ReadLineBaxIDFA(filepath+"/"+files[i].Name(), execFileIDFA, chs[i], i, myset)
	}

	for _, ch := range chs {
		<-ch
	}
}

func ReadLineBaxIDFA(fileName string, handler func(string, *Client, string) string, ch chan int, i int, myset string) error {

	f, err := os.Open(fileName)
	if err != nil {
		return err
	}

	client, err := NewClient(config.GetAsserver(), config.GetAsPort())
	if err != nil {
		return err
	}

	buf := bufio.NewReader(f)

	for {
		line, err := buf.ReadString('\n')
		line = strings.TrimSpace(line)
		ret := handler(line, client, myset)
		if ret == "end" || ret == "err" || ret == "MO" {
			break
		}
		if err != nil {
			if err == io.EOF {
				return nil
			}
			return err
		}
	}
	ch <- i
	return nil
}

func execFileIDFA(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")
		item := strings.Split(dat[1], ",")
		var buffer bytes.Buffer
		for i := 0; i < len(item); i++ {
			str := getInterestBaxMapping(item[i])

			if str != "" {
				if i == (len(item) - 2) {
					buffer.WriteString(str + ":1.0")
				} else {
					buffer.WriteString(str + ":1.0,")
				}
			}
		}

		key, err := NewKey(config.GetNamespase(), myset, dat[0])
		if err != nil {
			return "err"
		}

		tt3, err3 := client.Execute(nil, key, "updateIntt2", "updateIntt", NewValue(buffer.String()), NewValue(dat[0]))
		if err3 != nil {
			fmt.Println(err3)
			return "err"
		} else {
			fmt.Println(tt3)
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

//-------------------------------------------------bax idfa---------------------------------------------------------------------------------
