# -*- coding: utf-8 -*-

import smtplib,sys,os,time,datetime
from email.mime.text import  MIMEText

def send_mail(sub,content):
    ###############
    #要发送的人：
    mailto_list = ["wangxiaojie@social-touch.com","songhuiqing@social-touch.com"]
    ###################
    #设置服务器，用户名，口令以及邮箱后缀
    mail_host = "smtp.qiye.163.com"
    mail_user = "wangxiaojie@social-touch.com"
    mail_pass = "Admin@wxj"
    mail_postfix="social-touch.com"
    #####################
    
    me = mail_user + "<"+mail_user+"@"+mail_postfix+">"
    msg = MIMEText(content,_charset = 'gbk')
    msg['Subject'] = sub
    msg['From'] = me
    msg['To'] = ";".join(mailto_list)

    try:
        s = smtplib.SMTP()
        s.connect(mail_host)
        s.login(mail_user,mail_pass)
        s.sendmail(me,mailto_list,msg.as_string())
        s.close()
        return True
    except Exception, e:
        print str(e)
        return False

    
if __name__ =='__main__':
    ####################
    #检查文件是否存在：
    #file1 = time.strftime('%Y%m%d')
    myTime = time.strftime('%Y%m%d',time.localtime(time.time() - 24*60*60))
    filename = r'/data/hadoop/analysis/userprofile/user_profile_intt/output/adn//user_profile' + myTime + '.dat'
    IsExist=os.path.exists(filename)
    if IsExist == 1:
        data = open(filename).read()
        if len(data) !=0:
            content = u'文件已经更新完成并且有新data，可以去aerospike查看啦！'
        else:
            content = u'脚本已执行但没有data,需要huiqing检查。。。'
    else:
        content = u'文件不存在,需要huiqing检查。。。'
    if send_mail(u'定时update user脚本check', content):
        print u'发送成功'
    else:
        print u'发送失败'
        
