#!/bin/bash
source ~/.bash_profile
source /home/madfuhaijun/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

echo $DAY

USERDIR="/home/madfuhaijun/analysis/userprofile/user_profile_intt"

 log(){
         echo "`date +%Y%m%d-%H%M%S` :  $@"
 }

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/adx_tmp/adview/imei/*
rm -rf ${USERDIR}/output/adx_tmp/adview/idfa/*

#从mysql中查询interest_youku_maping所有数据到本地interest_youku_maping.dat文件中
mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; select pkname, appname, gen_il_1_id, gen_il_1_name, gen_il_2_id, gen_il_2_name from interest_adview_maping;" > ${USERDIR}/interest_adview_maping.dat

log " hive create category table"
#在hive中创建app_im表
hive -S -e " drop table  if exists interest_adview_maping;
CREATE TABLE if not exists interest_adview_maping (
pkname STRING,
appname STRING,
gen_il_1_id STRING,
gen_il_1_name STRING,
gen_il_2_id STRING,
gen_il_2_name STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE;" 
#加载interest_adview_maping.dat中的数据到interest_adview_maping表
hive -S -e "load data local inpath '${USERDIR}/interest_adview_maping.dat' into table interest_adview_maping;"

hive -S -e "select t.imei, CONCAT_WS(',',collect_set(CONCAT(ia.gen_il_2_id, ':1.0'))) from interest_adview_maping ia left join (SELECT DISTINCT imei,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100004 AND platform='1' AND imei!='' AND imei!='0' AND imei!='000000' AND imei!='00000000' AND imei!='00000000000000' AND imei!='000000000000000' AND imei!='0000000000000000' and app_pkg != '') t on ia.pkname = t.app_pkg group by t.imei;" > ${USERDIR}/output/adx/adview/adview_intt_imei_${DAY}.log

hive -S -e "SELECT t.idfa, CONCAT_WS(',',collect_set(CONCAT(ia.gen_il_2_id, ':1.0'))) FROM interest_adview_maping ia LEFT JOIN (SELECT DISTINCT idfa,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100004 AND platform='2' AND idfa!='' AND idfa != '00000000-0000-0000-0000-000000000000' AND app_pkg != '') t on ia.pkname = t.app_pkg GROUP BY idfa;" > ${USERDIR}/output/adx/adview/adview_intt_idfa_${DAY}.log

cp ${USERDIR}/output/adx/adview/adview_intt_imei_${DAY}.log ${USERDIR}/output/adx_tmp/adview/imei
cp ${USERDIR}/output/adx/adview/adview_intt_idfa_${DAY}.log ${USERDIR}/output/adx_tmp/adview/idfa

cd ${USERDIR}/output/adx_tmp/adview/imei
split -l 50000 ${USERDIR}/output/adx_tmp/adview/imei/adview_intt_imei_${DAY}.log
cd ${USERDIR}/output/adx_tmp/adview/idfa
split -l 50000 ${USERDIR}/output/adx_tmp/adview/idfa/adview_intt_idfa_${DAY}.log

rm -rf ${USERDIR}/output/adx_tmp/adview/imei/adview_intt_imei_${DAY}.log
rm -rf ${USERDIR}/output/adx_tmp/adview/idfa/adview_intt_idfa_${DAY}.log

hive -S -e "insert overwrite table user_profile_day_adview_inclog partition (day_id='${DAY}')
select t.imei, ia.gen_il_2_id from interest_adview_maping ia join
(SELECT DISTINCT imei,app_pkg
FROM dmp_request
WHERE day_id = '${DAY}' AND adx_id = 100004 AND platform='1' AND imei!='' AND imei!='0' AND imei!='000000' AND imei!='00000000' AND imei!='00000000000000' AND imei!='000000000000000' AND imei!='0000000000000000' AND app_pkg != '') t ON ia.pkname = t.app_pkg;"

hive -S -e "insert overwrite table user_profile_day_adview_inclog partition (day_id='${DAY}')
select t.idfa, ia.gen_il_2_id from interest_adview_maping ia join
(SELECT DISTINCT idfa,app_pkg FROM dmp_request WHERE day_id = '${DAY}' AND adx_id = 100004 AND platform='2' AND idfa!='' AND idfa != '00000000-0000-0000-0000-000000000000' AND app_pkg != '') t ON ia.pkname = t.app_pkg;"

#得到昨天的昨天（前天）
BDAY=`date -d "${DAY} -1 day " +%Y%m%d`

hive -S -e "insert overwrite table user_profile_day_adview partition (day_id='${DAY}')
select t.user_id, t.g2 from
(select user_id, g2 from user_profile_day_adview_inclog where day_id = '${DAY}'
union all
select user_id, g2 from user_profile_day_adview where day_id = '${BDAY}') t group by t.user_id, t.g2;"

hive -S -e "select g2, count(DISTINCT user_id) from user_profile_day_adview where day_id = '${DAY}' group by g2;" > ${USERDIR}/output/adx/adview/g2_${DAY}.log

hive -S -e "select count(distinct user_id) from user_profile_day_adview where day_id = '${DAY}';" > ${USERDIR}/output/adx/adview/g2_count${DAY}.log

log " exec end "
