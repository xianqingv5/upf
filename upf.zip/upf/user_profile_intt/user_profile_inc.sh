#!/bin/bash
source ~/.bash_profile
source /data/hadoop/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

echo $DAY

USERDIR="/data/hadoop/analysis/userprofile/user_profile_intt"

log(){
        echo "`date +%Y%m%d-%H%M%S` :  $@"
}

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/adn_tmp/*

#ps aux|grep user_profile_intt | awk '{print $2}' | xargs kill -9

USERFILE="${USERDIR}/output/adn/user_profile${DAY}.dat"

if [ ! -f "$USERFILE" ]; then

#从mysql中查询app_im所有数据到本地mapping.dat文件中
/data/mysql/mysql/bin/mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; SELECT pkgname,categoryid,ostype,categoryname FROM app_im2;" > ${USERDIR}/mapping.dat

log " hive create category table"
#在hive中创建app_im表
/data/hadoop/hive/bin/hive -S -e " drop table  if exists app_im;
CREATE TABLE if not exists app_im (
app_pkg STRING,
cate_id STRING,
os STRING,
cate_name STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE;" 
#加载mapping.dat中的数据到app_im表
/data/hadoop/hive/bin/hive -S -e "load data local inpath '${USERDIR}/mapping.dat' into table app_im;"

log " hive sql insert app_user"
#从app_device中统计每一个app_user的app下载情况（统计出每个用户安装的APP列表）
/data/hadoop/hive/bin/hive -S -e " insert overwrite table app_user partition (day_id='${DAY}')
 select distinct t1.user_id,t2.app_pkg, 1 as os from  
 (
 select request_id,imei as user_id,app_pkg from app_device where
 day_id='${DAY}' and imei <>'\^' and imei<>'0' and imei<>'000000000000000' and imei<>'0000000000000000' and imei <>'111111111111111' and imei<>'00000000' and imei<>'00000000000000' 
 and imei<>'Unknown' and imei is not null and imei<>''
 ) t1 join ( select app_pkg,request_id from app_install where day_id='${DAY}' ) t2 on t1.request_id=t2.request_id ; "

log "hive sql user profile "

#------------------------------------------------------------------------------------
log "insert user_profile_day_inc_log"
#根据每个用户安装的app查出相应的兴趣标签，每个app权重分别为1，如果安装了n个同一兴趣标签的app，权重为n*1
/data/hadoop/hive/bin/hive -S -e " insert overwrite table user_profile_day_inc_log partition (day_id='${DAY}')  
select tt.user_id,tt.cate_id,count(1) as weight from
(
select t2.user_id,t1.cate_id from
(select app_pkg,cate_id from app_im ) t1 join
(select app_pkg,user_id from app_user where day_id='${DAY}' ) t2 on t1.app_pkg=t2.app_pkg
) tt group by  tt.user_id,tt.cate_id; " 

#得到昨天的昨天（前天）
BDAY=`date -d "${DAY} -1 day " +%Y%m%d`

#得到用户对应的兴趣标签以及权重（把昨天产生的新的兴趣标签合并到总标签上，然后保存在昨天的表中）
/data/hadoop/hive/bin/hive -S -e " insert overwrite table user_profile_day partition (day_id='${DAY}')
select t.user_id, t.cate_id, sum(t.weight) as weight from
(select user_id, cate_id, weight as weight from user_profile_day where day_id='${BDAY}'
union all
select user_id, cate_id, weight from user_profile_day_inc_log where day_id='${DAY}') t group by t.user_id, t.cate_id; "

#得到用户id对应的兴趣标签数据，格式：00000000921742  11:2,4:2,2:1,3:3
/data/hadoop/hive/bin/hive -S -e " insert overwrite table user_profile_output partition (day_id='${DAY}')
select user_id, concat_ws(',',collect_set(flag)) from
(
 select user_id,weight,concat(cate_id,':',weight) as flag  from user_profile_day where day_id='${DAY}'
) t group by user_id; "

log "hive sql user profile output "
#把最终的结果输出到文件中
/data/hadoop/hive/bin/hive -S -e "select user_id,user_value from user_profile_output where day_id='${DAY}' ;" > ${USERDIR}/output/adn/user_profile${DAY}.dat

log " hive sql user profile end "

fi

cp ${USERDIR}/output/adn/user_profile${DAY}.dat ${USERDIR}/output/adn_tmp
cd ${USERDIR}/output/adn_tmp
split -l 10000 ${USERDIR}/output/adn_tmp/user_profile${DAY}.dat
rm -rf ${USERDIR}/output/adn_tmp/user_profile${DAY}.dat

cd /data/hadoop/analysis/userprofile/user_profile_intt
pwd
#adn用户数据加入adnuser
/data/hadoop/analysis/userprofile/user_profile_intt/user_profile_intt_adn -dtype=1
#adn用户数据加入mwuser
/data/hadoop/analysis/userprofile/user_profile_intt/user_profile_intt_adn -dtype=2
#adn用户数据加入md5user
/data/hadoop/analysis/userprofile/user_profile_intt/user_profile_intt_adn -dtype=3
#adn用户数据加入sha1user
/data/hadoop/analysis/userprofile/user_profile_intt/user_profile_intt_adn -dtype=4

#日志监控程序
python logmonitor.py

/usr/bin/rsync -zrtopgl --bwlimit=8000 --progress /data/hadoop/analysis/userprofile/user_profile_intt/output/adn/user_profile${DAY}.dat 211.151.64.233::userprofile/user_profile_intt/output/adn

log " import data is end "
