//user_profile_intt_adx_youku.go
package youku

import (
	"bytes"
	"fmt"
	"strconv"
	"strings"
	"upf/config"
	. "upf/config"
	common "upf/user_profile_common"
	"upf/utils"
	. "upf/utils/date"
	"upf/utils/mysql"
	"upf/utils/str"

	. "github.com/aerospike/aerospike-client-go"
)

func execFile(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")
		item := strings.Split(dat[1], ",")
		var buffer bytes.Buffer
		for i := 0; i < len(item); i++ {
			str := getInterestYoukuMapping(item[i])

			if strings.Contains(buffer.String(), str+":1.0") {
				continue
			}

			if str != "" {
				buffer.WriteString(str + ":1.0,")
			}
		}

		key, err := NewKey(config.GetNamespase(), myset, dat[0])
		if err != nil {
			return "err"
		}

		if len(buffer.String()) == 0 {
			return ""
		}
		value := str.Substr(buffer.String(), 0, len(buffer.String())-1)
		//bin := NewBin("intt", value)

		tt3, err3 := client.Execute(nil, key, "updateIntt2", "updateIntt", NewValue(value), NewValue(dat[0]))
		//err3 := client.PutBins(nil, key, bin)
		if err3 != nil {
			fmt.Println(err3)
			return "err"
		} else {
			fmt.Println(tt3)
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}

func InttAdnYouku() {
	filepath := GetInttfilepath("UserProfileCrAdxYouku").Imei
	myset := "ykuser"
	common.ExecPROCS(filepath, myset, execFile)
	myset = "adnuser"
	common.ExecPROCS(filepath, myset, execFile)
	filepath = GetInttfilepath("UserProfileCrAdxYouku").Idfa
	myset = "mwuser"
	common.ExecPROCS(filepath, myset, execFile)
	myset = "adnuser"
	common.ExecPROCS(filepath, myset, execFile)
}

func getInterestYoukuMapping(s string) string {
	m2 := map[string]string{
		"2341":      "1201",
		"2315":      "15",
		"2317":      "15",
		"2353":      "15",
		"2358":      "13",
		"2143":      "1801",
		"2148":      "1801",
		"2219":      "1012",
		"2221":      "1004",
		"110309999": "901",
		"2034":      "902",
		"2038":      "901",
		"2039":      "901",
		"2040":      "902",
		"2041":      "902",
		"2043":      "902",
		"2050":      "902",
		"2065":      "902",
		"2067":      "902",
		"2068":      "901",
		"2070":      "901",
		"2074":      "901",
		"2077":      "901",
		"2098":      "903",
		"2135":      "903",
		"2146":      "9",
		"2199":      "904",
		"2223":      "904",
		"2224":      "904",
		"2226":      "904",
		"2309":      "9",
		"2321":      "9",
		"235":       "905",
		"236":       "905",
		"3038":      "906",
		"3039":      "906",
		"304":       "906",
		"3040":      "906",
		"3041":      "906",
		"3042":      "906",
		"3043":      "906",
		"3044":      "906",
		"3045":      "906",
		"3046":      "906",
		"3047":      "906",
		"3048":      "906",
		"3049":      "906",
		"305":       "906",
		"3050":      "906",
		"3051":      "906",
		"3052":      "906",
		"3053":      "906",
		"3054":      "906",
		"3055":      "906",
		"3062":      "9"}
	return m2[s]
}

// 把youku相关的通用兴趣标签设备数加入标签可视化功能中
func TagViewYouku() {
	// g2_20160831.log
	g2FileName := GetDtfilepathsMap()["intt"].Filepath + "/adx/youku/g2_" + GetYesDate() + ".log"
	// g2_count20160831.log
	g2CountFileName := GetDtfilepathsMap()["intt"].Filepath + "/adx/youku/g2_count" + GetYesDate() + ".log"
	if utils.IsExist(g2FileName) && utils.IsExist(g2CountFileName) {
		// 1,读取已有的通用兴趣标签数据
		m := mysql.GetUserProfileInttAdnByDate(GetYesDate())
		if len(m) > 0 {
			if size, _ := utils.FileSize(g2FileName); size > 0 {
				utils.ReadLine(g2FileName, func(line string) {
					if line != "" {
						dat := strings.Split(line, "\t")
						if m[dat[0]] == 0 { // 原来数据中没有此标签,需要新增
							v, _ := strconv.Atoi(dat[1])
							mysql.InsertInttAdn(dat[0], v)
						} else { // 已经存在,更新
							n, _ := strconv.Atoi(dat[1])
							v := n + m[dat[0]]
							mysql.UpdateUserProfileInttAdnByG2id(v, dat[0], GetYesDate())
						}
					}

				})
			}

			if size, _ := utils.FileSize(g2CountFileName); size > 0 {
				utils.ReadLine(g2CountFileName, func(line string) {
					if m["0"] != 0 {
						if line != "" {
							b, _ := strconv.Atoi(line)
							//mysql.InsertInttAdn("0", b+m["0"])
							mysql.UpdateUserProfileInttAdnByG2id(b+m["0"], "0", GetYesDate())
						}
					}
				})
			}
		}
	} else {

	}
}
