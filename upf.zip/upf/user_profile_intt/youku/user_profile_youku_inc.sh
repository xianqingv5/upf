#!/bin/bash
source ~/.bash_profile
source /home/madfuhaijun/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

echo $DAY

USERDIR="/home/madfuhaijun/analysis/userprofile/user_profile_intt"

 log(){
         echo "`date +%Y%m%d-%H%M%S` :  $@"
 }

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/adx_tmp/youku/imei/*
rm -rf ${USERDIR}/output/adx_tmp/youku/idfa/*

#从mysql中查询interest_youku_maping所有数据到本地interest_youku_maping.dat文件中
mysql -h ${mysqlip} -P${mysqlport} -u${username} -p${password} -D category -e "set character_set_connection = utf8; set character_set_client = utf8;  set character_set_results= utf8; SELECT gen_il_1_id,gen_il_1_name,youku_il_id,youku_il_name  FROM interest_youku_maping;" > ${USERDIR}/interest_youku_maping.dat

log " hive create category table"
#在hive中创建app_im表
hive -S -e " drop table  if exists interest_youku_maping;
CREATE TABLE if not exists interest_youku_maping (
gen_il_1_id STRING,
gen_il_1_name STRING,
youku_il_id STRING,
youku_il_name STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE;" 
#加载interest_youku_maping.dat中的数据到interest_youku_maping表
hive -S -e "load data local inpath '${USERDIR}/interest_youku_maping.dat' into table interest_youku_maping;"

hive -S -e "select imei, concat_ws(',',collect_set(adx_channel_second)) from (select distinct imei,adx_channel_second from dmp_request where day_id = '${DAY}' and adx_id = 100005 and platform='1' and imei!='' and imei!='0' and imei!='000000' and imei!='00000000' and imei!='00000000000000' and imei!='000000000000000' and imei!='0000000000000000' and adx_channel_second!='') t group by imei;" > ${USERDIR}/output/adx/youku/youku_intt_imei_${DAY}.log

hive -S -e "select idfa, concat_ws(',',collect_set(adx_channel_second)) from (select distinct idfa,adx_channel_second from dmp_request where day_id = '${DAY}' and adx_id = 100005 and platform='2' and idfa!='' and idfa != '00000000-0000-0000-0000-000000000000' and adx_channel_second!='') t group by idfa;" > ${USERDIR}/output/adx/youku/youku_intt_idfa_${DAY}.log

cp ${USERDIR}/output/adx/youku/youku_intt_imei_${DAY}.log ${USERDIR}/output/adx_tmp/youku/imei
cp ${USERDIR}/output/adx/youku/youku_intt_idfa_${DAY}.log ${USERDIR}/output/adx_tmp/youku/idfa

cd ${USERDIR}/output/adx_tmp/youku/imei
split -l 50000 ${USERDIR}/output/adx_tmp/youku/imei/youku_intt_imei_${DAY}.log
cd ${USERDIR}/output/adx_tmp/youku/idfa
split -l 50000 ${USERDIR}/output/adx_tmp/youku/idfa/youku_intt_idfa_${DAY}.log

rm -rf ${USERDIR}/output/adx_tmp/youku/imei/youku_intt_imei_${DAY}.log
rm -rf ${USERDIR}/output/adx_tmp/youku/idfa/youku_intt_idfa_${DAY}.log

#imei(bduser)
${USERDIR}/user_profile_intt_adx_youku -type=1
#idfa(mwuser)
${USERDIR}/user_profile_intt_adx_youku -type=2


hive -S -e "insert overwrite table user_profile_day_youku_inclog partition (day_id='${DAY}')
select t.imei, ia.gen_il_1_id from interest_youku_maping ia join
(SELECT DISTINCT imei,adx_channel_second
FROM dmp_request
WHERE day_id = '${DAY}' AND adx_id = 100005 AND platform='1' AND imei!='' AND imei!='0' AND imei!='000000' AND imei!='00000000' AND imei!='00000000000000' AND imei!='000000000000000' AND imei!='0000000000000000' AND adx_channel_second!='') t ON ia.youku_il_id = t.adx_channel_second;"

hive -S -e "insert overwrite table user_profile_day_youku_inclog partition (day_id='${DAY}')
select t.idfa, ia.gen_il_1_id from interest_youku_maping ia join
(select distinct idfa,adx_channel_second from dmp_request where day_id = '${DAY}' and adx_id = 100005 and platform='2' and idfa!='' and idfa != '00000000-0000-0000-0000-000000000000' and adx_channel_second!='') t ON ia.youku_il_id = t.adx_channel_second;"

#得到昨天的昨天（前天）
BDAY=`date -d "${DAY} -1 day " +%Y%m%d`

hive -S -e "insert overwrite table user_profile_day_youku partition (day_id='${DAY}')
select t.user_id, t.g2 from
(select user_id, g2 from user_profile_day_youku_inclog where day_id = '${DAY}'
union all
select user_id, g2 from user_profile_day_youku where day_id = '${BDAY}') t group by t.user_id, t.g2;"

hive -S -e "select g2, count(DISTINCT user_id) from user_profile_day_youku where day_id = '${DAY}' group by g2;" > ${USERDIR}/output/adx/youku/g2_${DAY}.log

hive -S -e "select count(distinct user_id) from user_profile_day_youku where day_id = '${DAY}';" > ${USERDIR}/output/adx/youku/g2_count${DAY}.log

log " exec end "
