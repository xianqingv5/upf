#!/bin/bash
source ~/.bash_profile
source /home/madfuhaijun/analysis/userprofile/config/readConfig.sh

INPUTDATE=${1}
if [ -z "${INPUTDATE}" ];then
DAY=`date +%Y%m%d -d "-1day" `
else
DAY=${INPUTDATE}
fi

DAY2=`date -d "${DAY} -90day " +%Y%m%d`

echo $DAY
echo $DAY2

USERDIR="/home/madfuhaijun/analysis/userprofile/user_profile_cr"

log(){
        echo "`date +%Y%m%d-%H%M%S` :  $@"
}

tos="songhuiqing@social-touch.com"
CheckIfError(){
if [ $? != 0 ];then
subject=$1
content=$2
curl -d "subject=$subject&content=`echo -e \"$content\"`&tos=$tos" "http://c.fuhaijun.com/mail/"
exit -1
fi
}

rm -rf ${USERDIR}/output/imei_tmp/*
rm -rf ${USERDIR}/output/idfa_tmp/*


log " exec rela_clk_limit_android "

hive -S -e "select imei, concat_ws(',', collect_set(advertiser_id)) from rela_clk_limit where platform = 1 and day_id<='${DAY}' and day_id>='${DAY2}' group by imei;" > ${USERDIR}/output/cr/imei${DAY}-90.log
hive -S -e "select advertiser_id,count(0) from rela_clk_limit where platform = 1 and day_id='${DAY}' group by advertiser_id;" > ${USERDIR}/output/cr/imei_count_${DAY}.log

log " exec rela_clk_limit_ios "
hive -S -e "select idfa, concat_ws(',', collect_set(advertiser_id)) from rela_clk_limit where platform = 1 and day_id<='${DAY}' and day_id>='${DAY2}' group by idfa;" > ${USERDIR}/output/cr/idfa${DAY}-90.log
hive -S -e "select advertiser_id,count(0) from rela_clk_limit where platform = 1 and day_id='${DAY}' group by advertiser_id;" > ${USERDIR}/output/cr/idfa_count_${DAY}.log

hive -S -e "select advertiser_id, count(distinct user_id) from rela_clk_limit where day_id<='${DAY}' and day_id>='${DAY2}' group by advertiser_id;" > ${USERDIR}/output/cr/adv_click_${DAY}.dat

cp ${USERDIR}/output/cr/imei${DAY}-90.log ${USERDIR}/output/imei_tmp
cd ${USERDIR}/output/imei_tmp
split -l 1000 ${USERDIR}/output/imei_tmp/imei${DAY}-90.log
rm -rf ${USERDIR}/output/imei_tmp/imei${DAY}-90.log

cp ${USERDIR}/output/cr/idfa${DAY}-90.log ${USERDIR}/output/idfa_tmp
cd ${USERDIR}/output/idfa_tmp
split -l 1000 ${USERDIR}/output/idfa_tmp/idfa${DAY}-90.log
rm -rf ${USERDIR}/output/idfa_tmp/idfa${DAY}-90.log

log " hive exec end  "
