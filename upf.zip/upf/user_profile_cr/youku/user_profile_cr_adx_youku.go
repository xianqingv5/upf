//user_profile_cr_adx_youku
package youku

import (
	"flag"
	"upf/config"
	upcr "upf/user_profile_cr"
)

func main() {
	type2 := flag.String("type", "1", "default adn is 1")
	flag.Parse()

	filepath := config.GetUpffilePath("UserProfileCrAdxYouku").Imei
	filepath_idfa := config.GetUpffilePath("UserProfileCrAdxYouku").Imei

	if *type2 == "1" { // ykuser
		myset := "ykuser"
		upcr.ExecCr(filepath, myset)      // imei
		upcr.ExecCr(filepath_idfa, myset) // idfa
	} else if *type2 == "2" { // mwuser
		myset := "mwuser"
		upcr.ExecCr(filepath_idfa, myset) // idfa
	} else if *type2 == "3" { // md5user
		myset := "md5user"
		upcr.ExecCr(filepath, myset)
	} else if *type2 == "4" { // sha1user

	}
}

func UserProfileCrYouku() {
	filepath := config.GetUpffilePath("UserProfileCrAdxYouku").Imei
	filepath_idfa := config.GetUpffilePath("UserProfileCrAdxYouku").Imei

	// ykuser
	myset := "ykuser"
	upcr.ExecCr(filepath, myset)      // imei
	upcr.ExecCr(filepath_idfa, myset) // idfa
	// mwuser
	myset = "mwuser"
	upcr.ExecCr(filepath_idfa, myset) // idfa
	// md5user
	myset = "md5user"
	upcr.ExecCr(filepath, myset)
	// sha1user
}
