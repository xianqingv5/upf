//user_profile_cr
package user_profile_cr

import (
	"os/exec"
	"strings"
	"upf/config"
	. "upf/user_profile_common"
	"upf/utils"

	. "github.com/aerospike/aerospike-client-go"
)

func UserProfileCr() {
	filepath := "/home/madfuhaijun/analysis/userprofile/user_profile_cr/output/imei_tmp"
	filepath_idfa := "/home/madfuhaijun/analysis/userprofile/user_profile_cr/output/idfa_tmp"
	if utils.IsExist(filepath) && utils.IsExist(filepath_idfa) {
		goto A
	} else {
		cmd := exec.Command("/bin/sh", "/home/madfuhaijun/analysis/userprofile/user_profile_cr/user_profile_cr.sh")
		b2, err := cmd.Output()
		if err != nil {
			panic(err)
		} else {
			println(string(b2[:len(b2)]))
			goto A
		}
	}
A:
	{
		//adnuser
		myset := "adnuser"
		ExecPROCS(filepath, myset, ExecFile)
		ExecPROCS(filepath_idfa, myset, ExecFile)
		//mwuser
		myset = "mwuser"
		ExecPROCS(filepath, myset, ExecFile)
		ExecPROCS(filepath_idfa, myset, ExecFile)
		//md5user
		myset = "md5user"
		ExecPROCS(filepath, myset, ExecFile)
		//sha1user
		myset = "sha1user"
		ExecPROCS(filepath, myset, ExecFile)
	}
}

func ExecFile(line string, client *Client, myset string) string {
	if line != "" {
		dat := strings.Split(line, "\t")
		key, err := NewKey(config.GetNamespase(), myset, utils.GetEncryptionKey(myset, dat[0]))
		if err != nil {
			return "err"
		}

		cr := NewBin("cr", dat[1])
		err = client.PutBins(nil, key, cr)
		if err != nil {
			return "err"
		}

		return "SUCC"
	} else {
		return "end"
	}
	return "MO"
}
