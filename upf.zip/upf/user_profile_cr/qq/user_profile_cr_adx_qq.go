//qq
package qq

import (
	"upf/config"
	upcr "upf/user_profile_cr"
)

func UserProfileCrQQ() {
	filepath := config.GetUpffilePath("UserProfileCrAdxQQ").Imei
	filepath_idfa := config.GetUpffilePath("UserProfileCrAdxQQ").Imei
	//qquser
	myset := "qquser"
	upcr.ExecCr(filepath, myset)      //imei
	upcr.ExecCr(filepath_idfa, myset) //idfa
	//mwuser
	myset = "mwuser"
	upcr.ExecCr(filepath_idfa, myset) //idfa
	//md5user
	myset = "md5user"
	upcr.ExecCr(filepath, myset)
	//sha1user
}
