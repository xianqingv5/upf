//wax
package wax

import (
	"upf/config"
	upfcr "upf/user_profile_cr"
)

func UserProfileCrWax() {
	filepath := config.GetUpffilePath("UserProfileCrAdxWax").Imei
	filepath_idfa := config.GetUpffilePath("UserProfileCrAdxWax").Imei
	// waxuser
	myset := "waxuser"
	upfcr.ExecCr(filepath, myset)      // imei
	upfcr.ExecCr(filepath_idfa, myset) // idfa
	// mwuser
	myset = "mwuser"
	upfcr.ExecCr(filepath_idfa, myset) // idfa
	// md5user
	myset = "md5user"
	upfcr.ExecCr(filepath, myset)
	// sha1user
}
