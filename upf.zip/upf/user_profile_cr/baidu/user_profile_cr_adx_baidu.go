//user_profile_insat
package baidu

import (
	"upf/config"
	upfcr "upf/user_profile_cr"
)

func UserProfileCrBaidu() {

	filepath := config.GetUpffilePath("UserProfileCrAdxBaidu").Imei
	filepath_idfa := config.GetUpffilePath("UserProfileCrAdxBaidu").Idfa

	//bduser
	myset := "bduser"
	upfcr.ExecCr(filepath, myset)      //imei
	upfcr.ExecCr(filepath_idfa, myset) //idfa
	//mwuser
	myset = "mwuser"
	upfcr.ExecCr(filepath_idfa, myset) //idfa
	//md5user
	myset = "md5user"
	upfcr.ExecCr(filepath, myset)
	//sha1user
}
