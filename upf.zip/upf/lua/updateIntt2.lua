local function Split(szFullString, szSeparator)
  local nFindStartIndex = 1
  local nSplitIndex = 1
  local nSplitArray = {}
  while true do
    local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
    if not nFindLastIndex then
      nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
      break
    end
    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
    nFindStartIndex = nFindLastIndex + string.len(szSeparator)
    nSplitIndex = nSplitIndex + 1
  end
  return nSplitArray
end

function updateIntt(rec,appendIntt,sqid)
	local ret = map()
	
	if not aerospike:exists(rec) then
      	ret['status'] = 'DOES NOT EXIST'
      	rec['sqid'] = sqid
      	rec['intt'] = appendIntt
      	aerospike:create(rec)
  else
		   local intt = rec['intt']
      if intt == nil then
          rec['intt'] = appendIntt
          ret['status'] = 'INTT DOES NOT EXIST'
	        ret['intt'] = appendIntt
      else
          ret['status'] = 'INTT DOES EXIST'
	        local intt = rec['intt']
	        local appendIntt = appendIntt
          local list = Split(appendIntt, ',')
          for k, v in pairs(list) do
            local item = Split(list[k], ":")
            local l1 = item[1] .. ':'
             if string.find(intt, l1) ~= nil then
                ret['status'] = 'appendIntt is old'
                
             else
                ret['status'] = 'appendIntt is new'
                intt = intt .. ',' .. list[k]
                rec['intt'] = intt
                ret['intt'] = intt
             end
          end         	        
      end
      aerospike:update(rec)       
	end
	return ret
end
