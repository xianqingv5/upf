function countintt(rec)
  local ret = map()
  --aerospike:update(rec)
  ret['intt'] = 'songhuiqng'
  return ret
end