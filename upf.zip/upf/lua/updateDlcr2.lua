function updateDlcr(rec,appendDlcr,advertiserid,appid,acttype)
  local ret = map()

  if not aerospike:exists(rec) then--判断rec记录是否存在
      ret['status'] = 'DOES NOT EXIST'
      rec['ddor'] = appendDlcr
      aerospike:create(rec)--不存在则创建一个新的key, 属性为sqid和dlcr
  else--key存在则更新ddor属性的值
      local dlcr = rec['ddor']
      if dlcr == nil then
          rec['ddor'] = appendDlcr
          ret['status'] = 'DLCR DOES NOT EXIST'  
          ret['ddor'] = appendDlcr
      else
          ret['status'] = 'DLCR DOES EXIST'  
          local dlcr = rec['ddor']  
          dlcr[advertiserid .. '|' .. appid] = acttype
          rec['ddor'] = dlcr          
      end
      aerospike:update(rec)--修改
  end
  --aerospike:update(rec)
  return ret
end