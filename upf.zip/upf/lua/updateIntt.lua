local function Split(szFullString, szSeparator)
  local nFindStartIndex = 1
  local nSplitIndex = 1
  local nSplitArray = {}
  while true do
    local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)
    if not nFindLastIndex then
      nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))
      break
    end
    nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)
    nFindStartIndex = nFindLastIndex + string.len(szSeparator)
    nSplitIndex = nSplitIndex + 1
  end
  return nSplitArray
end

function updateIntt(rec,appendIntt,sqid)
  local ret = map()

  if not aerospike:exists(rec) then
      ret['status'] = 'DOES NOT EXIST'
      rec['sqid'] = sqid['sqid']
      rec['intt'] = appendIntt['appendIntt']
      aerospike:create(rec)
  else
      --ret['status'] = 'DOES EXIST'
      local intt = rec['intt']
      if intt == nil then
          --rec['sqid'] = userid['userid']
          rec['intt'] = appendIntt['appendIntt']
          ret['status'] = 'INTT DOES NOT EXIST'
	        ret['intt'] = appendIntt['appendIntt']
      else
          ret['status'] = 'INTT DOES EXIST'
	        local intt = rec['intt']
	        local appendIntt = appendIntt['appendIntt']
	        local list = Split(appendIntt, ':')
	        local l1 = list[1] .. ':'
	        if string.find(intt, l1) ~= nil then
		        ret['status'] = 'appendIntt is old'
		        local l2 = list[2]
		        --local list2 = Split(intt, ':')
		        ret['l2'] = l2
	        else
		        ret['status'] = 'appendIntt is new'
		        rec['intt'] = intt .. ',' .. appendIntt
		        ret['intt'] = intt .. ',' .. appendIntt
	        end	  
      end
      aerospike:update(rec)
  end
  --aerospike:update(rec)
  return ret
end

