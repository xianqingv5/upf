function updateDlcr(rec,appendDlcr,sqid,advertiserid,appid,acttype)
  local ret = map()

  if not aerospike:exists(rec) then--�ж�rec��¼�Ƿ����
      ret['status'] = 'DOES NOT EXIST'
      rec['sqid'] = sqid['sqid']
      rec['ddor'] = appendDlcr['appendDlcr']
      aerospike:create(rec)--�������򴴽�һ���µ�key, ����Ϊsqid��dlcr
  else--key���������intt���Ե�ֵ
      local dlcr = rec['ddor']
      if dlcr == nil then
          rec['ddor'] = appendDlcr['appendDlcr']  
          ret['status'] = 'DLCR DOES NOT EXIST'  
          ret['ddor'] = appendDlcr['appendDlcr']
      else
          ret['status'] = 'DLCR DOES EXIST'  
          local dlcr = rec['ddor']  
          dlcr[advertiserid['advertiserid'] .. '|' .. appid['appid']] = acttype['acttype']
          rec['ddor'] = dlcr          
      end
      aerospike:update(rec)--�޸�
  end
  --aerospike:update(rec)
  return ret
end

